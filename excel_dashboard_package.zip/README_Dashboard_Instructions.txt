Excel Dashboard Template Package
Files included:
1) dashboard_template.xlsx  - Excel workbook with sample data and sheets (RawData, CleanData, Dashboard, Instructions)
2) refresh_export_macro.bas - VBA module file containing the RefreshAndExport macro (import into your workbook)
3) README_Dashboard_Instructions.txt - this file (you're reading it)

Important notes:
- The included .xlsx is a template with sample data. It does NOT contain the VBA macro inside because automated creation of .xlsm with embedded Power Query and macros is not possible here.
- To enable full automation (one-click refresh + export as PDF), you must import the provided .bas file into the workbook and save as a macro-enabled workbook (.xlsm).

How to import the VBA .bas into the workbook:
1. Open dashboard_template.xlsx in Excel.
2. Save it immediately as an Excel Macro-Enabled Workbook:
   File -> Save As -> choose folder -> Save as type: Excel Macro-Enabled Workbook (*.xlsm) -> Save.
3. Enable the Developer tab if you don't have it:
   File -> Options -> Customize Ribbon -> on the right check 'Developer' -> OK.
4. Press Alt+F11 to open the VBA editor (Visual Basic for Applications).
5. In the VBA editor: File -> Import File... -> choose refresh_export_macro.bas -> Open.
6. You should now see a module named RefreshExportModule in the Modules folder.
7. Close the VBA editor.
8. Optionally, add a button on the Dashboard sheet:
   - Developer -> Insert -> Button (Form Control) -> draw button on Dashboard -> Assign Macro -> pick 'RefreshAndExport' -> OK.
9. Save again as .xlsm. When opening, enable macros to allow the button to run.

How to complete Power Query steps (manual):
1. In Excel, select any cell inside the table on RawData.
2. Data -> From Table/Range. This opens Power Query Editor.
3. In Power Query, perform these transforms (click each in order):
   - Transform -> Format -> Trim (for text columns)
   - Change Data Type (click the icon left of columns)
   - Home -> Remove Rows -> Remove Duplicates
   - Add Column -> Custom Column -> Name: TotalRevenue -> Formula: =[UnitPrice]*[Quantity]
4. Home -> Close & Load To... -> Table -> Existing Worksheet -> choose CleanData!A1 and Load.
5. Create pivot tables/charts from the CleanData table on separate sheets as described in the Instructions sheet.

Limitations & why this package is structured this way:
- Creating a fully-featured .xlsm file with embedded Power Query steps and pivot tables programmatically in this environment is limited. Power Query steps are user-specific and easier to set up interactively in Excel so you can confirm each transform.
- This package gives you the workbook, the exact VBA code (so you can import it), and a clear step-by-step README and Instructions sheet to finish the dashboard interactively in Excel.

If you want, I can now:
- A) Generate a fully populated .xlsm here with the macro embedded (I will try to create one but you may need to re-enable macros and import the Power Query manually), or
- B) Walk you step-by-step while you import the .bas and finish the Power Query and pivots live (tell me where you get stuck).

Which would you like?